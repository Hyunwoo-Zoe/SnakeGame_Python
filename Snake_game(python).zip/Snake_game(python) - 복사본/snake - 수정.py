
import sys
import subprocess
subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'pygame'])

import pygame
import random
import time


# ##### 1-1. 게임 사전 설정
# 게임에 대한 기본적인 설정에 대한 변수 들을 미리 정의

# Frame 수 조절(초당 그려지는 수)
fps = 15

# 창의 크기
frame = (720, 480)

# 색깔 정의 (Red, Green, Blue)
black = pygame.Color(0, 0, 0)
white = pygame.Color(255, 255, 255)
red = pygame.Color(255, 0, 0)
green = pygame.Color(0, 255, 0)
blue = pygame.Color(0, 0, 255)

# 시간을 흐르게 하기 위한 FPS counter
fps_controller = pygame.time.Clock()

# Game 관련 변수들
#snake 머리/몸통 위치
snake_pos1 = [100, 50]
snake_body1 = [[100, 50], [100-10, 50], [100-(2*10), 50]]

snake_pos2 = [620, 50]
snake_body2 = [[620, 50], [620+10, 50], [620+(2*10), 50]]
#음식 이미지 불러오기 및 크기 변환
food=pygame.image.load("C:\\Users\\a0102\\OneDrive\\바탕 화면\\python workspace\\Snake_game(python)\\사진\\apple.jpg")
food=pygame.transform.scale(food,(40,40))
#음식 이미지 위치 랜덤 설정
food_pos = [random.randrange(1, (frame[0]//10) * 10 - 80),
            random.randrange(1, (frame[1]//10) * 10 - 80)]
food_spawn = True
#snake의 초기 방향 설정정
direction1 = 'd'
direction2 = 'LEFT'

score1 = 0
score2 = 0

# ##### 1-2. Pygame 초기화(Initialize Pygame)
# Pygame을 사용하기 위해 창 크기, 제목 등을 주어 초기화를 함
# 만약 초기화를 실패하였다면 오류를 알려주고 종료함
# 함수로 만들어서 게임이 동작하기 전에 불러올수 있게 함

def Init(size):
    # 초기화 후 error발생 여부 확인인
    check_errors = pygame.init()

    # pygame.init() example output -> (6, 0)
    # 두번째 항목이 error의 수를 알려줌줌
    if check_errors[1] > 0:
        print(
            f'[!] Had {check_errors[1]} errors when initialising game, exiting...')
        sys.exit(-1)
    else:
        print('[+] Game successfully initialised')

    # pygame.display를 통해 제목, window size를 설정하고 초기화합니다.
    # Initialise game window using pygame.display
    pygame.display.set_caption('Snake Example with PyGame')
    game_window = pygame.display.set_mode(size)
    return game_window

# ##### 1-3. 기본 logic 함수 모음

# 1) Score 생성 함수
def show_score(window, size, choice, color1, color2, font, fontsize):
    score_font = pygame.font.SysFont(font, fontsize)
    # Player1의 score 설정
    score_surface1 = score_font.render('Player1 : ' + str(score1), True, color1)
    score_rect1 = score_surface1.get_rect()
    # Player2의 score 설정
    score_surface2 = score_font.render('Player2 : ' + str(score2), True, color2)
    score_rect2 = score_surface2.get_rect()

    # Game이 진행 중이라면 상단에 score 표시
    if choice == 1:
        score_rect1.midtop = (size[0]/10, 15)
    else:
        score_rect1.midtop = (size[0]/4, size[1]/1.25)
    # Game이 끝났다면 중하단에 score 표시
    if choice == 1:
        score_rect2.midtop = (size[0]*9/10, 15)
    else:
        score_rect2.midtop = (size[0]*3/4, size[1]/1.25)

    # 설정한 score를 window(화면)에 표시
    window.blit(score_surface1, score_rect1)
    window.blit(score_surface2, score_rect2)


# 2) Game Over 문구 생성 함수
def game_over(window, size):
    # 'Game Over'문구 설정
    my_font = pygame.font.SysFont('times new roman', 90)
    game_over_surface = my_font.render('Game Over', True, black)
    game_over_rect = game_over_surface.get_rect()
    game_over_rect.midtop = (size[0]/2, size[1]/4)

    # window를 흰색으로 칠하고 설정했던 문구구를 window에 표시
    window.fill(white)
    window.blit(game_over_surface, game_over_rect)

    # 'show_score' 함수 호출 -> 'Game Over'문구 아래에 score 표시
    show_score(window, size, 0, red, blue, 'times', 20)

    # 그려진 화면을 생성
    pygame.display.flip()

    # 3초 기다린 후 게임 종료
    time.sleep(3)
    pygame.quit()
    sys.exit()


# 3) Keyboard 입력 함수
def get_keyboard1(key, cur_dir):
    # WASD를 입력 받으면 해당 방향으로 이동
    # 방향이 반대방향이면 무시

    if direction1 != 's' and key == ord('w'):
        return 'w'
    if direction1 != 'w' and key == ord('s'):
        return 's'
    if direction1 != 'd' and key == ord('a'):
        return 'a'
    if direction1 != 'a' and key == ord('d'):
        return 'd'
    # 모두 해당하지 않다면 원래 방향을 return
    return cur_dir

def get_keyboard2(key, cur_dir):
    # 방향키를 입력 받으면 해당 방향으로 이동
    # 방향이 반대방향이면 무시
    if direction2 != 'DOWN' and key == pygame.K_UP:
        return 'UP'
    if direction2 != 'UP' and key == pygame.K_DOWN:
        return 'DOWN'
    if direction2 != 'RIGHT' and key == pygame.K_LEFT:
        return 'LEFT'
    if direction2 != 'LEFT' and key == pygame.K_RIGHT:
        return 'RIGHT'
    # 모두 해당하지 않다면 원래 방향을 return
    return cur_dir


# #### 2. 메인 프로그램
# Game이 동작하기 위한 메인 코드

# 화면 초기화
main_window = Init(frame)

while True:
    # 게임에서 event를 받아옵니다.
    for event in pygame.event.get():
        # 종료시 실제로 프로그램을 종료합니다.
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif event.type == pygame.KEYDOWN:
            # esc 키를 눌렀을떄 종료 신호를 보냅니다.
            if event.key == pygame.K_ESCAPE:
                pygame.event.post(pygame.event.Event(pygame.QUIT))
            else:
                # 입력 키로 방향을 얻어냅니다.
                direction1 = get_keyboard1(event.key, direction1)
                direction2 = get_keyboard2(event.key, direction2)

    # 실제로 뱀의 위치를 이동
    #Player1
    if direction1 == 'w':
        snake_pos1[1] -= 10
    if direction1 == 's':
        snake_pos1[1] += 10
    if direction1 == 'a':
        snake_pos1[0] -= 10
    if direction1 == 'd':
        snake_pos1[0] += 10
    #Player2
    if direction2 == 'UP':
        snake_pos2[1] -= 10
    if direction2 == 'DOWN':
        snake_pos2[1] += 10
    if direction2 == 'LEFT':
        snake_pos2[0] -= 10
    if direction2 == 'RIGHT':
        snake_pos2[0] += 10


    # 우선 증가시키고 음식의 위치가 아니라면 마지막을 뺍니다.
    snake_body1.insert(0, list(snake_pos1))
    if food_pos[0] <= snake_pos1[0] <= food_pos[0]+40 and food_pos[1] <= snake_pos1[1] <= food_pos[1]+40:
        score1 += 1
        food_spawn = False
    else:
        snake_body1.pop()

    snake_body2.insert(0, list(snake_pos2))
    if food_pos[0] <= snake_pos2[0] <= food_pos[0]+40 and food_pos[1] <= snake_pos2[1] <= food_pos[1]+40:
        score2 += 1
        food_spawn = False
    else:
        snake_body2.pop()

    # 음식이 없다면 음식을 랜덤한 위치에 생성합니다.
    if not food_spawn:
        food_pos = [
            random.randrange(1, (frame[0]//10)) * 10,
            random.randrange(1, (frame[1]//10)) * 10
        ]
    food_spawn = True

    # 우선 게임을 흰 색으로 채우고 뱀의 각 위치마다 그림을 그립니다.
    main_window.fill(white)

    #Player1의 snake 머리를 빨간색으로 설정
    pygame.draw.rect(main_window, red ,pygame.Rect(snake_body1[0][0], snake_body1[0][1], 10, 10))
    #머리를 제외한 몸통은 for문을 통해 초록색으로 설정
    for pos in snake_body1[1:]:
        pygame.draw.rect(main_window, green,
                         pygame.Rect(pos[0], pos[1], 10, 10))
    #Player2의 snake 머리를 파란란색으로 설정
    pygame.draw.rect(main_window, blue, pygame.Rect(snake_body2[0][0], snake_body2[0][1], 10, 10))
    #머리를 제외한 몸통은 for문을 통해 초록색으로 설정
    for pos in snake_body2[1:]:
        pygame.draw.rect(main_window, green,
                         pygame.Rect(pos[0], pos[1], 10, 10))
        
    # 음식을 그립니다.
    
    main_window.blit(food,(food_pos[0], food_pos[1]))

    # Game Over 상태를 확인합니다.

    # 바깥 벽 처리
    if snake_pos1[0] < 0 or snake_pos1[0] > frame[0] - 10:
        game_over(main_window, frame)
    if snake_pos1[1] < 0 or snake_pos1[1] > frame[1] - 10:
        game_over(main_window, frame)

    if snake_pos2[0] < 0 or snake_pos2[0] > frame[0] - 10:
        game_over(main_window, frame)
    if snake_pos2[1] < 0 or snake_pos2[1] > frame[1] - 10:
        game_over(main_window, frame)

    # 뱀이 자신의 몸에 닿았는지 확인
    for block in snake_body1[1:]:
        if snake_pos1[0] == block[0] and snake_pos1[1] == block[1]:
            game_over(main_window, frame)

    for block in snake_body2[1:]:
        if snake_pos2[0] == block[0] and snake_pos2[1] == block[1]:
            game_over(main_window, frame)

    #뱀끼리 충돌 시 게임오버
    for i in snake_body1:
        for j in snake_body2:
            if i[0]==j[0] and i[1]==j[1]:
                game_over(main_window, frame)

    # 점수를 띄워줌줌
    show_score(main_window, frame, 1, red, blue, 'consolas', 20)

    # 실제 화면에 보이도록 업데이트
    pygame.display.update()

    # 해당 FPS만큼 대기
    fps_controller.tick(fps)

